lookup-client
=============

An Android mobile client to find new people in your vicinity. 
